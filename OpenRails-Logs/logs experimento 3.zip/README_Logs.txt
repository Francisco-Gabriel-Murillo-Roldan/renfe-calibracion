Annotated logs showing evolution from unstable configurations to the final calibration.

May 2026