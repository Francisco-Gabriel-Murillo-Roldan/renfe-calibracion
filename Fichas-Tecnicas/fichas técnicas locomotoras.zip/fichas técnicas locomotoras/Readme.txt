TECHNICAL DATASHEETS – RENFE DIESEL LOCOMOTIVES
=================================================

This compressed file contains the technical datasheets (in PDF format) for the
diesel locomotive series calibrated and documented in the main repository.

The following series are included:
- RENFE 313 (ALCO DL-535-S)
- RENFE 316 (ALCO DL-500-A)
- RENFE 318 (ALCO DL-500-C)
- RENFE 319.0 (EMD G-16)
- RENFE 319.2 (GM / MACOSA "Retal")
- RENFE 319.3 (GM / MEINFESA "Grandes Líneas")
- RENFE 319.4 (GM / MEINFESA "SuperSerie")
- RENFE 321 (ALCO DL-500-S)
- RENFE 333.0 (GM / NOHAB)
- RENFE 333.3 (Vossloh Euro 3000 / Alstom) – Freight version
- RENFE 333.4 (Vossloh Euro 3000 / Alstom) – Passenger version

CONTENTS OF THIS FILE
---------------------

Each datasheet includes:
- Locomotive identification and technical specifications.
- Validated parameters for Open Rails (adhesion, traction, braking).
- Experimental results (grade performance, acceleration, braking distances).
- Weather behaviour (dry, rain, snow).
- Summary of the final calibration (MaxPower, MaxForce, CK parameters, etc.).

WHAT IS NOT INCLUDED
--------------------

This archive contains NO original Open Rails files (no .eng, .inc, .s, .sd, sound
files, or any other asset from third-party add-ons). The datasheets are original
documentation created by the author, based on personal analysis and calibration
work on legitimate copies of the software.

These documents are intended to accompany the analysis presented in the GitHub
repository and to serve as a technical portfolio.

LICENSE
-------

This documentation is shared under the MIT License. You are free to use, share,
and adapt it, as long as you give appropriate credit to the original author.

For the full license text, please refer to the LICENSE file in the repository.

Author: Francisco Gabriel Murillo Roldán
Date: June 2026